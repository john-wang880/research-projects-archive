*----------------------------------------------------------------------
* 3D GGEE Dynamic-CSL IGBT Ic-Vc simulation
* Condition: VGE = 15 V, VCE = 0 -> 5 V, T = 300 K.
* All electrodes start from 0 V. AreaFactor = 1e6.
*----------------------------------------------------------------------

File {
   Grid      = "@tdr@"
   Parameter = "@parameter@"
   Plot      = "@tdrdat@"
   Current   = "@plot@"
   Output    = "@log@"
}

Electrode {
   { Name="emitter"   Voltage=0.0 }
   { Name="gate"      Voltage=0.0 }
   { Name="collector" Voltage=0.0 }
}

Physics {
   Temperature = 300
   AreaFactor  = 1e6

   Fermi
   EffectiveIntrinsicDensity(
      BandGapNarrowing(Slotboom)
   )
}

Physics(Material="Silicon") {
   Mobility(
      DopingDependence
      Enormal(IALMob)
      HighFieldSaturation(GradQuasiFermi)
   )

   Recombination(
      SRH(DopingDependence TempDependence)
      Auger
   )
}

Physics(Material="PolySilicon") {
   Mobility(DopingDependence)
   Recombination(SRH(DopingDependence TempDependence) Auger)
}

Plot {
   eDensity hDensity
   eCurrent/Vector hCurrent/Vector TotalCurrent/Vector
   Potential ElectricField/Vector SpaceCharge
   Doping DonorConcentration AcceptorConcentration
   eMobility hMobility eVelocity hVelocity
   eQuasiFermi hQuasiFermi
   eGradQuasiFermi/Vector hGradQuasiFermi/Vector
   ConductionBand ValenceBand BandGap
   SRHRecombination AugerRecombination
}

Math {
   Extrapolate
   Derivatives
   RelErrControl

   Digits=5
   ErrRef(Electron)=1e10
   ErrRef(Hole)=1e10
   RHSMin=1e-10

   Iterations=50
   NotDamped=18
   Method=ParDiSo

   RefDens_eGradQuasiFermi_ElectricField_HFS=1e12
   RefDens_hGradQuasiFermi_ElectricField_HFS=1e12
   ParallelToInterfaceInBoundaryLayer
   SimStats
}

Solve {
   * Equilibrium initialization.
   Coupled(
      Iterations=120
      LineSearchDamping=1e-4
   ) {
      Poisson
   }

   Coupled(
      Iterations=100
      LineSearchDamping=1e-3
   ) {
      Poisson Electron Hole
   }

   * Establish the inversion channel first: VGE = 0 -> 15 V at VCE = 0 V.
   NewCurrentPrefix="IcVc_GateInit_"

   Quasistationary(
      InitialStep=1e-3
      Increment=1.40
      Decrement=2.0
      MinStep=1e-8
      MaxStep=0.025
      Goal { Name="gate" Voltage=15.0 }
   ) {
      Coupled(
         Iterations=55
         LineSearchDamping=0.20
      ) {
         Poisson Electron Hole
      }
   }

   Save(FilePrefix="n@node@_IcVc_Vge15V")

   * Output characteristic stage 1: resolve the low-VCE injection transition.
   NewCurrentPrefix="IcVc_"

   Quasistationary(
      InitialStep=2e-4
      Increment=1.25
      Decrement=2.0
      MinStep=1e-9
      MaxStep=0.010
      Goal { Name="collector" Voltage=1.0 }
   ) {
      Coupled(
         Iterations=70
         LineSearchDamping=0.12
      ) {
         Poisson Electron Hole
      }

      CurrentPlot(
         Time=(Range=(0.0 1.0) Intervals=100)
      )
   }

   * Output characteristic stage 2: VCE = 1 -> 5 V.
   Quasistationary(
      InitialStep=5e-4
      Increment=1.35
      Decrement=2.0
      MinStep=1e-9
      MaxStep=0.020
      Goal { Name="collector" Voltage=5.0 }
   ) {
      Coupled(
         Iterations=65
         LineSearchDamping=0.18
      ) {
         Poisson Electron Hole
      }

      CurrentPlot(
         Time=(Range=(0.0 1.0) Intervals=160)
      )
   }

   Plot(FilePrefix="n@node@_IcVc_Final")
}

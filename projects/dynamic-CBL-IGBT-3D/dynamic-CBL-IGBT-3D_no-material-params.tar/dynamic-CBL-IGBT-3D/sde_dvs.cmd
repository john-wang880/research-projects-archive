;--------------------------------------------------------------------------
; 3D proposed GGEE-type trench IGBT with Dynamic-CSL
; Compact mesh and Gaussian N+/P+ junction profiles
; True transverse sequence: E - E - G - G - E - E.
; Channel-P exists only below the segmented N+ source blocks.
; The source-free Wp intervals are separate lower-doped Dynamic-CSL volumes.
; Coordinates: X = vertical depth, Y = transverse cell direction,
;              Z = trench/source-segmentation direction.
;--------------------------------------------------------------------------

(sde:clear)

;--------------------------------------------------------------------------
; Workbench parameters
;--------------------------------------------------------------------------

(define ChannelDensity @ChannelDensity@)
(define NA.ChannelP    @NA_ChannelP@)
(define NA.DynamicCSL  @NA_DynamicCSL@)

;--------------------------------------------------------------------------
; Materials
;--------------------------------------------------------------------------

(define Mat.Si    "Silicon")
(define Mat.Ox    "Oxide")
(define Mat.Poly  "PolySilicon")
(define Mat.Metal "Aluminum")

;--------------------------------------------------------------------------
; Region names
;--------------------------------------------------------------------------

(define Reg.Si "R.Silicon")

(define Reg.E0.Poly "R.E0.Poly")
(define Reg.E0.Ox   "R.E0.Ox")
(define Reg.E1.Poly "R.E1.Poly")
(define Reg.E1.Ox   "R.E1.Ox")
(define Reg.G1.Poly "R.G1.Poly")
(define Reg.G1.Ox   "R.G1.Ox")
(define Reg.G2.Poly "R.G2.Poly")
(define Reg.G2.Ox   "R.G2.Ox")
(define Reg.E2.Poly "R.E2.Poly")
(define Reg.E2.Ox   "R.E2.Ox")
(define Reg.E3.Poly "R.E3.Poly")
(define Reg.E3.Ox   "R.E3.Ox")

;--------------------------------------------------------------------------
; Vertical dimensions in X [um]
;--------------------------------------------------------------------------

(define X.Top         0.00)
(define X.Source      0.40)
(define X.DummyPPlus  0.35)
(define X.PBase       3.20)
(define X.FLP         4.20)
(define X.Trench      5.00)
(define X.FieldStop  64.00)
(define X.Collector  68.00)
(define X.Bottom     70.00)

(define T.Ox         0.10)
(define X.PolyBottom (- X.Trench T.Ox))
(define R.Trench     0.22)
(define R.Poly       (- R.Trench T.Ox))

;--------------------------------------------------------------------------
; GGEE transverse layout in Y [um]
;
; E0(half) | EE-L | E1 | FLP-L | G1 | Active | G2 | FLP-R | E2 | EE-R | E3(half)
;--------------------------------------------------------------------------

(define W.EmitterTrench 0.50)
(define W.EECell        0.45)
(define W.FLP           1.20)
(define W.GateTrench    0.55)
(define W.Active        0.80)

(define Y.Left 0.00)

(define Y.E0.Left  Y.Left)
(define Y.E0.Right (+ Y.E0.Left (/ W.EmitterTrench 2.0)))

(define Y.EEL.Left  Y.E0.Right)
(define Y.EEL.Right (+ Y.EEL.Left W.EECell))

(define Y.E1.Left  Y.EEL.Right)
(define Y.E1.Right (+ Y.E1.Left W.EmitterTrench))

(define Y.FLPL.Left  Y.E1.Right)
(define Y.FLPL.Right (+ Y.FLPL.Left W.FLP))

(define Y.G1.Left  Y.FLPL.Right)
(define Y.G1.Right (+ Y.G1.Left W.GateTrench))

(define Y.Act.Left  Y.G1.Right)
(define Y.Act.Right (+ Y.Act.Left W.Active))

(define Y.G2.Left  Y.Act.Right)
(define Y.G2.Right (+ Y.G2.Left W.GateTrench))

(define Y.FLPR.Left  Y.G2.Right)
(define Y.FLPR.Right (+ Y.FLPR.Left W.FLP))

(define Y.E2.Left  Y.FLPR.Right)
(define Y.E2.Right (+ Y.E2.Left W.EmitterTrench))

(define Y.EER.Left  Y.E2.Right)
(define Y.EER.Right (+ Y.EER.Left W.EECell))

(define Y.E3.Left  Y.EER.Right)
(define Y.E3.Right (+ Y.E3.Left (/ W.EmitterTrench 2.0)))
(define Y.Right    Y.E3.Right)

(define Y.E0.Center  (/ (+ Y.E0.Left  Y.E0.Right)  2.0))
(define Y.EEL.Center (/ (+ Y.EEL.Left Y.EEL.Right) 2.0))
(define Y.E1.Center  (/ (+ Y.E1.Left  Y.E1.Right)  2.0))
(define Y.G1.Center  (/ (+ Y.G1.Left  Y.G1.Right)  2.0))
(define Y.Act.Center (/ (+ Y.Act.Left Y.Act.Right) 2.0))
(define Y.G2.Center  (/ (+ Y.G2.Left  Y.G2.Right)  2.0))
(define Y.E2.Center  (/ (+ Y.E2.Left  Y.E2.Right)  2.0))
(define Y.EER.Center (/ (+ Y.EER.Left Y.EER.Right) 2.0))
(define Y.E3.Center  (/ (+ Y.E3.Left  Y.E3.Right)  2.0))

;--------------------------------------------------------------------------
; Segmented source layout in Z [um]
;
; Two complete periods are retained so the top view contains two complete
; N+ source blocks, matching the paper schematic more directly.
; The external boundaries are centered in source-free Wp regions.
;--------------------------------------------------------------------------

(define Z.Period 10.00)
(define Wn (* ChannelDensity Z.Period))
(define Wp (- Z.Period Wn))

(define Z.Left  0.00)
(define Z.Right (* 2.0 Z.Period))
(define Z.Mid   (/ Z.Right 2.0))

(define Z.Source1.Left  (/ Wp 2.0))
(define Z.Source1.Right (+ Z.Source1.Left Wn))
(define Z.Source2.Left  (+ Z.Period (/ Wp 2.0)))
(define Z.Source2.Right (+ Z.Source2.Left Wn))

;--------------------------------------------------------------------------
; Doping parameters [cm^-3]
;--------------------------------------------------------------------------

(define ND.Drift       8.0e13)
(define ND.FieldStop   5.0e16)
(define NA.Collector   1.0e19)
(define NA.DummyPBase  5.0e16)
(define NA.FLP         4.0e16)
(define ND.Source      1.0e20)
(define NA.DummyPPlus  5.0e19)
(define ND.Poly        1.0e20)

;--------------------------------------------------------------------------
; Rounded polysilicon trench cores
; Create the old poly bodies first. The later oxide bodies are trimmed by
; these cores using BAB, which avoids voids at the rounded oxide/poly bottom.
;--------------------------------------------------------------------------

(sdegeo:set-default-boolean "BAB")

; E0: left boundary half emitter trench.
(define Body.E0.Poly
  (sdegeo:create-cuboid
    (position X.Top Y.E0.Left Z.Left)
    (position X.PolyBottom (- Y.E0.Right T.Ox) Z.Right)
    Mat.Poly Reg.E0.Poly))
(sdegeo:fillet
  (list (car (find-edge-id
    (position X.PolyBottom (- Y.E0.Right T.Ox) Z.Mid))))
  R.Poly #t)

; E1: left inner emitter trench.
(define Body.E1.Poly
  (sdegeo:create-cuboid
    (position X.Top (+ Y.E1.Left T.Ox) Z.Left)
    (position X.PolyBottom (- Y.E1.Right T.Ox) Z.Right)
    Mat.Poly Reg.E1.Poly))
(sdegeo:fillet
  (list
    (car (find-edge-id (position X.PolyBottom (+ Y.E1.Left T.Ox) Z.Mid)))
    (car (find-edge-id (position X.PolyBottom (- Y.E1.Right T.Ox) Z.Mid))))
  R.Poly #t)

; G1: left active gate trench.
(define Body.G1.Poly
  (sdegeo:create-cuboid
    (position X.Top (+ Y.G1.Left T.Ox) Z.Left)
    (position X.PolyBottom (- Y.G1.Right T.Ox) Z.Right)
    Mat.Poly Reg.G1.Poly))
(sdegeo:fillet
  (list
    (car (find-edge-id (position X.PolyBottom (+ Y.G1.Left T.Ox) Z.Mid)))
    (car (find-edge-id (position X.PolyBottom (- Y.G1.Right T.Ox) Z.Mid))))
  R.Poly #t)

; G2: right active gate trench.
(define Body.G2.Poly
  (sdegeo:create-cuboid
    (position X.Top (+ Y.G2.Left T.Ox) Z.Left)
    (position X.PolyBottom (- Y.G2.Right T.Ox) Z.Right)
    Mat.Poly Reg.G2.Poly))
(sdegeo:fillet
  (list
    (car (find-edge-id (position X.PolyBottom (+ Y.G2.Left T.Ox) Z.Mid)))
    (car (find-edge-id (position X.PolyBottom (- Y.G2.Right T.Ox) Z.Mid))))
  R.Poly #t)

; E2: right inner emitter trench.
(define Body.E2.Poly
  (sdegeo:create-cuboid
    (position X.Top (+ Y.E2.Left T.Ox) Z.Left)
    (position X.PolyBottom (- Y.E2.Right T.Ox) Z.Right)
    Mat.Poly Reg.E2.Poly))
(sdegeo:fillet
  (list
    (car (find-edge-id (position X.PolyBottom (+ Y.E2.Left T.Ox) Z.Mid)))
    (car (find-edge-id (position X.PolyBottom (- Y.E2.Right T.Ox) Z.Mid))))
  R.Poly #t)

; E3: right boundary half emitter trench.
(define Body.E3.Poly
  (sdegeo:create-cuboid
    (position X.Top (+ Y.E3.Left T.Ox) Z.Left)
    (position X.PolyBottom Y.E3.Right Z.Right)
    Mat.Poly Reg.E3.Poly))
(sdegeo:fillet
  (list (car (find-edge-id
    (position X.PolyBottom (+ Y.E3.Left T.Ox) Z.Mid))))
  R.Poly #t)

;--------------------------------------------------------------------------
; Rounded trench oxide shells
;--------------------------------------------------------------------------

; E0 oxide shell.
(define Body.E0.Ox
  (sdegeo:create-cuboid
    (position X.Top Y.E0.Left Z.Left)
    (position X.Trench Y.E0.Right Z.Right)
    Mat.Ox Reg.E0.Ox))
(sdegeo:fillet
  (list (car (find-edge-id
    (position X.Trench Y.E0.Right Z.Mid))))
  R.Trench #t)

; E1 oxide shell.
(define Body.E1.Ox
  (sdegeo:create-cuboid
    (position X.Top Y.E1.Left Z.Left)
    (position X.Trench Y.E1.Right Z.Right)
    Mat.Ox Reg.E1.Ox))
(sdegeo:fillet
  (list
    (car (find-edge-id (position X.Trench Y.E1.Left Z.Mid)))
    (car (find-edge-id (position X.Trench Y.E1.Right Z.Mid))))
  R.Trench #t)

; G1 oxide shell.
(define Body.G1.Ox
  (sdegeo:create-cuboid
    (position X.Top Y.G1.Left Z.Left)
    (position X.Trench Y.G1.Right Z.Right)
    Mat.Ox Reg.G1.Ox))
(sdegeo:fillet
  (list
    (car (find-edge-id (position X.Trench Y.G1.Left Z.Mid)))
    (car (find-edge-id (position X.Trench Y.G1.Right Z.Mid))))
  R.Trench #t)

; G2 oxide shell.
(define Body.G2.Ox
  (sdegeo:create-cuboid
    (position X.Top Y.G2.Left Z.Left)
    (position X.Trench Y.G2.Right Z.Right)
    Mat.Ox Reg.G2.Ox))
(sdegeo:fillet
  (list
    (car (find-edge-id (position X.Trench Y.G2.Left Z.Mid)))
    (car (find-edge-id (position X.Trench Y.G2.Right Z.Mid))))
  R.Trench #t)

; E2 oxide shell.
(define Body.E2.Ox
  (sdegeo:create-cuboid
    (position X.Top Y.E2.Left Z.Left)
    (position X.Trench Y.E2.Right Z.Right)
    Mat.Ox Reg.E2.Ox))
(sdegeo:fillet
  (list
    (car (find-edge-id (position X.Trench Y.E2.Left Z.Mid)))
    (car (find-edge-id (position X.Trench Y.E2.Right Z.Mid))))
  R.Trench #t)

; E3 oxide shell.
(define Body.E3.Ox
  (sdegeo:create-cuboid
    (position X.Top Y.E3.Left Z.Left)
    (position X.Trench Y.E3.Right Z.Right)
    Mat.Ox Reg.E3.Ox))
(sdegeo:fillet
  (list (car (find-edge-id
    (position X.Trench Y.E3.Left Z.Mid))))
  R.Trench #t)

;--------------------------------------------------------------------------
; Silicon body
; Old rounded oxide/poly bodies replace the new Silicon body in BAB mode.
;--------------------------------------------------------------------------

(define Body.Si
  (sdegeo:create-cuboid
    (position X.Top Y.Left Z.Left)
    (position X.Bottom Y.Right Z.Right)
    Mat.Si Reg.Si))

(sdegeo:set-default-boolean "ABA")

;--------------------------------------------------------------------------
; Contacts
;
; The emitter metal is continuous over the complete active mesa along Z,
; matching Fig. 1(c,d). N+ remains segmented underneath this continuous metal.
; The two EE cells are contacted through their P+ top regions.
;--------------------------------------------------------------------------

(sdegeo:define-contact-set "emitter"   4.0 (color:rgb 1.0 0.0 0.0) "##")
(sdegeo:define-contact-set "gate"      4.0 (color:rgb 0.0 0.8 0.0) "##")
(sdegeo:define-contact-set "collector" 4.0 (color:rgb 0.0 0.0 1.0) "##")

; Emitter-connected trench polysilicon tops: E0, E1, E2, E3.
(sdegeo:set-contact
  (list
    (car (find-face-id (position X.Top Y.E0.Center Z.Mid)))
    (car (find-face-id (position X.Top Y.E1.Center Z.Mid)))
    (car (find-face-id (position X.Top Y.E2.Center Z.Mid)))
    (car (find-face-id (position X.Top Y.E3.Center Z.Mid))))
  "emitter")

; Active gate polysilicon tops: G1 and G2.
(sdegeo:set-contact
  (list
    (car (find-face-id (position X.Top Y.G1.Center Z.Mid)))
    (car (find-face-id (position X.Top Y.G2.Center Z.Mid))))
  "gate")

; Collector backside.
(sdegeo:set-contact
  (list (car (find-face-id
    (position X.Bottom Y.Act.Center Z.Mid))))
  "collector")

; Temporary contact box imprints the continuous active-mesa emitter contact.
(define Contact.Margin 0.02)
(define X.Contact.Top -0.10)

(define Tmp.ActiveEmitter
  (sdegeo:create-cuboid
    (position X.Contact.Top (+ Y.Act.Left Contact.Margin) Z.Left)
    (position X.Top (- Y.Act.Right Contact.Margin) Z.Right)
    Mat.Metal "Tmp.ActiveEmitter"))
(sdegeo:set-contact Tmp.ActiveEmitter "emitter" "remove")

(define Tmp.DummyPPlusL
  (sdegeo:create-cuboid
    (position X.Contact.Top (+ Y.EEL.Left Contact.Margin) Z.Left)
    (position X.Top (- Y.EEL.Right Contact.Margin) Z.Right)
    Mat.Metal "Tmp.DummyPPlusL"))
(sdegeo:set-contact Tmp.DummyPPlusL "emitter" "remove")

(define Tmp.DummyPPlusR
  (sdegeo:create-cuboid
    (position X.Contact.Top (+ Y.EER.Left Contact.Margin) Z.Left)
    (position X.Top (- Y.EER.Right Contact.Margin) Z.Right)
    Mat.Metal "Tmp.DummyPPlusR"))
(sdegeo:set-contact Tmp.DummyPPlusR "emitter" "remove")

;--------------------------------------------------------------------------
; Doping profile parameters for Gaussian N+/P+ regions [cm^-3, um]
; P-base and floating-P remain constant profiles; semiconductor N+/P+ junctions
; use Gaussian primary and lateral distributions.
;--------------------------------------------------------------------------

(define ND.FieldStop.Tail 8.0e13)
(define D.FieldStop       4.00)
(define L.FieldStop.Lat   0.20)

(define NA.Collector.Tail 1.0e17)
(define D.Collector       2.00)
(define L.Collector.Lat   0.15)

(define ND.Source.Tail    1.0e17)
(define D.Source          X.Source)
(define L.Source.Lat      0.08)

(define NA.DummyPPlus.Tail 1.0e17)
(define D.DummyPPlus       X.DummyPPlus)
(define L.DummyPPlus.Lat   0.06)

;--------------------------------------------------------------------------
; Doping: N- drift background
;--------------------------------------------------------------------------

(sdedr:define-constant-profile
  "Dop.NDrift" "PhosphorusActiveConcentration" ND.Drift)
(sdedr:define-constant-profile-region
  "Place.NDrift" "Dop.NDrift" Reg.Si)

;--------------------------------------------------------------------------
; Doping: Gaussian N+ field-stop profile
; Peak is placed at the field-stop/collector-side reference plane and decays
; toward the N- drift region. The P+ collector profile dominates at backside.
;--------------------------------------------------------------------------

(sdedr:define-gaussian-profile "Prof.FieldStop"
  "PhosphorusActiveConcentration"
  "PeakPos" 0.0 "PeakVal" ND.FieldStop
  "ValueAtDepth" ND.FieldStop.Tail "Depth" D.FieldStop
  "Gauss" "Length" L.FieldStop.Lat)

(sdedr:define-refeval-window "Base.FieldStop" "Rectangle"
  (position X.Collector Y.Left Z.Left)
  (position X.Collector Y.Right Z.Right))

(sdedr:define-analytical-profile-placement "Place.FieldStop.Gauss"
  "Prof.FieldStop" "Base.FieldStop" "Both" "NoReplace" "Eval")

;--------------------------------------------------------------------------
; Doping: Gaussian P+ backside collector
;--------------------------------------------------------------------------

(sdedr:define-gaussian-profile "Prof.CollectorPPlus"
  "BoronActiveConcentration"
  "PeakPos" 0.0 "PeakVal" NA.Collector
  "ValueAtDepth" NA.Collector.Tail "Depth" D.Collector
  "Gauss" "Length" L.Collector.Lat)

(sdedr:define-refeval-window "Base.CollectorPPlus" "Rectangle"
  (position X.Bottom Y.Left Z.Left)
  (position X.Bottom Y.Right Z.Right))

(sdedr:define-analytical-profile-placement "Place.CollectorPPlus.Gauss"
  "Prof.CollectorPPlus" "Base.CollectorPPlus" "Both" "NoReplace" "Eval")

;--------------------------------------------------------------------------
; Doping: proposed active-cell Channel-P and Dynamic-CSL
;
; IMPORTANT: these windows are complementary and do not overlap.
; Channel-P exists only below Source1 and Source2 (Wn intervals).
; Dynamic-CSL fills all source-free Wp intervals at the same vertical depth.
; This avoids retaining a high-concentration P-base underneath the DCSL.
;--------------------------------------------------------------------------

(sdedr:define-constant-profile
  "Dop.ChannelP" "BoronActiveConcentration" NA.ChannelP)
(sdedr:define-constant-profile
  "Dop.DynamicCSL" "BoronActiveConcentration" NA.DynamicCSL)

; Channel-P columns directly below the two N+ source blocks.
(sdedr:define-refeval-window "Win.ChannelP.Source1" "Cuboid"
  (position X.Top Y.Act.Left Z.Source1.Left)
  (position X.PBase Y.Act.Right Z.Source1.Right))
(sdedr:define-refeval-window "Win.ChannelP.Source2" "Cuboid"
  (position X.Top Y.Act.Left Z.Source2.Left)
  (position X.PBase Y.Act.Right Z.Source2.Right))
(sdedr:define-constant-profile-placement
  "Place.ChannelP.Source1" "Dop.ChannelP" "Win.ChannelP.Source1" 0.0 "LocalReplace")
(sdedr:define-constant-profile-placement
  "Place.ChannelP.Source2" "Dop.ChannelP" "Win.ChannelP.Source2" 0.0 "LocalReplace")

; Dynamic-CSL in the three source-free Wp pieces of this two-period domain.
(sdedr:define-refeval-window "Win.DynamicCSL.Left" "Cuboid"
  (position X.Top Y.Act.Left Z.Left)
  (position X.PBase Y.Act.Right Z.Source1.Left))
(sdedr:define-refeval-window "Win.DynamicCSL.Middle" "Cuboid"
  (position X.Top Y.Act.Left Z.Source1.Right)
  (position X.PBase Y.Act.Right Z.Source2.Left))
(sdedr:define-refeval-window "Win.DynamicCSL.Right" "Cuboid"
  (position X.Top Y.Act.Left Z.Source2.Right)
  (position X.PBase Y.Act.Right Z.Right))
(sdedr:define-constant-profile-placement
  "Place.DynamicCSL.Left" "Dop.DynamicCSL" "Win.DynamicCSL.Left" 0.0 "LocalReplace")
(sdedr:define-constant-profile-placement
  "Place.DynamicCSL.Middle" "Dop.DynamicCSL" "Win.DynamicCSL.Middle" 0.0 "LocalReplace")
(sdedr:define-constant-profile-placement
  "Place.DynamicCSL.Right" "Dop.DynamicCSL" "Win.DynamicCSL.Right" 0.0 "LocalReplace")

;--------------------------------------------------------------------------
; Doping: P-base in the two EE/dummy cells
;--------------------------------------------------------------------------

(sdedr:define-constant-profile
  "Dop.DummyPBase" "BoronActiveConcentration" NA.DummyPBase)
(sdedr:define-refeval-window "Win.PBase.EEL" "Cuboid"
  (position X.Top Y.EEL.Left Z.Left)
  (position X.PBase Y.EEL.Right Z.Right))
(sdedr:define-refeval-window "Win.PBase.EER" "Cuboid"
  (position X.Top Y.EER.Left Z.Left)
  (position X.PBase Y.EER.Right Z.Right))
(sdedr:define-constant-profile-placement
  "Place.PBase.EEL" "Dop.DummyPBase" "Win.PBase.EEL" 0.0 "LocalReplace")
(sdedr:define-constant-profile-placement
  "Place.PBase.EER" "Dop.DummyPBase" "Win.PBase.EER" 0.0 "LocalReplace")

;--------------------------------------------------------------------------
; Doping: deep floating P-dummy regions
;--------------------------------------------------------------------------

(sdedr:define-refeval-window "Win.FLP.Left" "Cuboid"
  (position X.Top Y.FLPL.Left Z.Left)
  (position X.FLP Y.FLPL.Right Z.Right))
(sdedr:define-refeval-window "Win.FLP.Right" "Cuboid"
  (position X.Top Y.FLPR.Left Z.Left)
  (position X.FLP Y.FLPR.Right Z.Right))
(sdedr:define-constant-profile
  "Dop.FLP" "BoronActiveConcentration" NA.FLP)
(sdedr:define-constant-profile-placement
  "Place.FLP.Left" "Dop.FLP" "Win.FLP.Left" 0.0 "LocalReplace")
(sdedr:define-constant-profile-placement
  "Place.FLP.Right" "Dop.FLP" "Win.FLP.Right" 0.0 "LocalReplace")

;--------------------------------------------------------------------------
; Doping: Gaussian P+ tops in the two EE/dummy cells
;--------------------------------------------------------------------------

(sdedr:define-gaussian-profile "Prof.DummyPPlus"
  "BoronActiveConcentration"
  "PeakPos" 0.0 "PeakVal" NA.DummyPPlus
  "ValueAtDepth" NA.DummyPPlus.Tail "Depth" D.DummyPPlus
  "Gauss" "Length" L.DummyPPlus.Lat)

(sdedr:define-refeval-window "Base.DummyPPlus.Left" "Rectangle"
  (position X.Top Y.EEL.Left Z.Left)
  (position X.Top Y.EEL.Right Z.Right))
(sdedr:define-refeval-window "Base.DummyPPlus.Right" "Rectangle"
  (position X.Top Y.EER.Left Z.Left)
  (position X.Top Y.EER.Right Z.Right))

(sdedr:define-analytical-profile-placement "Place.DummyPPlus.Left.Gauss"
  "Prof.DummyPPlus" "Base.DummyPPlus.Left" "Both" "NoReplace" "Eval")
(sdedr:define-analytical-profile-placement "Place.DummyPPlus.Right.Gauss"
  "Prof.DummyPPlus" "Base.DummyPPlus.Right" "Both" "NoReplace" "Eval")

;--------------------------------------------------------------------------
; Doping: Gaussian segmented N+ source blocks
; N+ covers the entire active mesa width in Y and is segmented only in Z.
;--------------------------------------------------------------------------

(sdedr:define-gaussian-profile "Prof.SourceNPlus"
  "ArsenicActiveConcentration"
  "PeakPos" 0.0 "PeakVal" ND.Source
  "ValueAtDepth" ND.Source.Tail "Depth" D.Source
  "Gauss" "Length" L.Source.Lat)

(sdedr:define-refeval-window "Base.Source1" "Rectangle"
  (position X.Top Y.Act.Left Z.Source1.Left)
  (position X.Top Y.Act.Right Z.Source1.Right))
(sdedr:define-refeval-window "Base.Source2" "Rectangle"
  (position X.Top Y.Act.Left Z.Source2.Left)
  (position X.Top Y.Act.Right Z.Source2.Right))

(sdedr:define-analytical-profile-placement "Place.Source1.Gauss"
  "Prof.SourceNPlus" "Base.Source1" "Both" "NoReplace" "Eval")
(sdedr:define-analytical-profile-placement "Place.Source2.Gauss"
  "Prof.SourceNPlus" "Base.Source2" "Both" "NoReplace" "Eval")

;--------------------------------------------------------------------------
; Doping: conductive polysilicon
; Poly doping remains constant because it is an electrode conductor, not a
; semiconductor junction implant.
;--------------------------------------------------------------------------

(sdedr:define-constant-profile
  "Dop.Poly" "PhosphorusActiveConcentration" ND.Poly)
(sdedr:define-constant-profile-material
  "Place.Poly" "Dop.Poly" Mat.Poly)

;--------------------------------------------------------------------------
; Compact 3D mesh
; Target: approximately 1e5-2e5 vertices for ChannelDensity=0.22.
; Source-edge boxes now also resolve the full-depth Channel-P/Dynamic-CSL boundary.
; Exact point count depends on the SDE mesher/version and generated topology.
;--------------------------------------------------------------------------

; Global drift mesh: no global doping-gradient refinement.
(sdedr:define-refeval-window "Win.Mesh.Global" "Cuboid"
  (position X.Top Y.Left Z.Left)
  (position X.Bottom Y.Right Z.Right))
(sdedr:define-refinement-size "RefDef.Mesh.Global"
  8.00 1.20 2.50
  1.00 0.18 0.60)
(sdedr:define-refinement-placement
  "RefPlace.Mesh.Global" "RefDef.Mesh.Global" "Win.Mesh.Global")

; Upper cell mesh, deliberately coarse along Z away from source edges.
(sdedr:define-refeval-window "Win.Mesh.Top" "Cuboid"
  (position X.Top Y.Left Z.Left)
  (position 6.00 Y.Right Z.Right))
(sdedr:define-refinement-size "RefDef.Mesh.Top"
  0.80 0.50 1.50
  0.12 0.08 0.50)
(sdedr:define-refinement-placement
  "RefPlace.Mesh.Top" "RefDef.Mesh.Top" "Win.Mesh.Top")
(sdedr:define-refinement-function "RefDef.Mesh.Top"
  "DopingConcentration" "MaxTransDiff" 1.5)

; Rounded trench bottoms and oxide interfaces.
(sdedr:define-refeval-window "Win.Mesh.TrenchBottom" "Cuboid"
  (position (- X.Trench 0.60) Y.Left Z.Left)
  (position (+ X.Trench 0.60) Y.Right Z.Right))
(sdedr:define-refinement-size "RefDef.Mesh.Trench"
  0.35 0.20 1.50
  0.07 0.04 0.50)
(sdedr:define-refinement-placement
  "RefPlace.Mesh.Trench" "RefDef.Mesh.Trench" "Win.Mesh.TrenchBottom")
(sdedr:define-refinement-function "RefDef.Mesh.Trench"
  "MaxLenInt" Mat.Si Mat.Ox 0.040 1.80 "DoubleSide")
(sdedr:define-refinement-function "RefDef.Mesh.Trench"
  "MaxLenInt" Mat.Ox Mat.Poly 0.050 1.80 "DoubleSide")

; Active MOS channel and vertical N+/P-base junction.
(sdedr:define-refeval-window "Win.Mesh.Active" "Cuboid"
  (position X.Top (- Y.G1.Left 0.08) Z.Left)
  (position (+ X.PBase 0.60) (+ Y.G2.Right 0.08) Z.Right))
(sdedr:define-refinement-size "RefDef.Mesh.Active"
  0.40 0.20 1.20
  0.05 0.035 0.30)
(sdedr:define-refinement-placement
  "RefPlace.Mesh.Active" "RefDef.Mesh.Active" "Win.Mesh.Active")
(sdedr:define-refinement-function "RefDef.Mesh.Active"
  "DopingConcentration" "MaxTransDiff" 1.2)

; EE/dummy P-base and Gaussian P+ contact cells.
(sdedr:define-refeval-window "Win.Mesh.EEL" "Cuboid"
  (position X.Top (- Y.EEL.Left 0.06) Z.Left)
  (position (+ X.PBase 0.40) (+ Y.EEL.Right 0.06) Z.Right))
(sdedr:define-refeval-window "Win.Mesh.EER" "Cuboid"
  (position X.Top (- Y.EER.Left 0.06) Z.Left)
  (position (+ X.PBase 0.40) (+ Y.EER.Right 0.06) Z.Right))
(sdedr:define-refinement-size "RefDef.Mesh.EE"
  0.45 0.18 1.50
  0.08 0.04 0.60)
(sdedr:define-refinement-placement
  "RefPlace.Mesh.EEL" "RefDef.Mesh.EE" "Win.Mesh.EEL")
(sdedr:define-refinement-placement
  "RefPlace.Mesh.EER" "RefDef.Mesh.EE" "Win.Mesh.EER")
(sdedr:define-refinement-function "RefDef.Mesh.EE"
  "DopingConcentration" "MaxTransDiff" 1.3)

; Fine Z mesh at the four Channel-P/Dynamic-CSL and N+ termination edges.
; The refinement extends through the full Channel-P/Dynamic-CSL depth.
(define Z.EdgePad 0.25)

(sdedr:define-refeval-window "Win.Mesh.Source1.Left" "Cuboid"
  (position X.Top (- Y.Act.Left 0.06) (- Z.Source1.Left Z.EdgePad))
  (position (+ X.PBase 0.40) (+ Y.Act.Right 0.06) (+ Z.Source1.Left Z.EdgePad)))
(sdedr:define-refeval-window "Win.Mesh.Source1.Right" "Cuboid"
  (position X.Top (- Y.Act.Left 0.06) (- Z.Source1.Right Z.EdgePad))
  (position (+ X.PBase 0.40) (+ Y.Act.Right 0.06) (+ Z.Source1.Right Z.EdgePad)))
(sdedr:define-refeval-window "Win.Mesh.Source2.Left" "Cuboid"
  (position X.Top (- Y.Act.Left 0.06) (- Z.Source2.Left Z.EdgePad))
  (position (+ X.PBase 0.40) (+ Y.Act.Right 0.06) (+ Z.Source2.Left Z.EdgePad)))
(sdedr:define-refeval-window "Win.Mesh.Source2.Right" "Cuboid"
  (position X.Top (- Y.Act.Left 0.06) (- Z.Source2.Right Z.EdgePad))
  (position (+ X.PBase 0.40) (+ Y.Act.Right 0.06) (+ Z.Source2.Right Z.EdgePad)))

(sdedr:define-refinement-size "RefDef.Mesh.SourceEdge"
  0.35 0.14 0.22
  0.07 0.035 0.055)
(sdedr:define-refinement-placement
  "RefPlace.Mesh.Source1.Left" "RefDef.Mesh.SourceEdge" "Win.Mesh.Source1.Left")
(sdedr:define-refinement-placement
  "RefPlace.Mesh.Source1.Right" "RefDef.Mesh.SourceEdge" "Win.Mesh.Source1.Right")
(sdedr:define-refinement-placement
  "RefPlace.Mesh.Source2.Left" "RefDef.Mesh.SourceEdge" "Win.Mesh.Source2.Left")
(sdedr:define-refinement-placement
  "RefPlace.Mesh.Source2.Right" "RefDef.Mesh.SourceEdge" "Win.Mesh.Source2.Right")
(sdedr:define-refinement-function "RefDef.Mesh.SourceEdge"
  "DopingConcentration" "MaxTransDiff" 1.0)

; Field-stop/P+ collector region.
(sdedr:define-refeval-window "Win.Mesh.Collector" "Cuboid"
  (position (- X.FieldStop 1.00) Y.Left Z.Left)
  (position X.Bottom Y.Right Z.Right))
(sdedr:define-refinement-size "RefDef.Mesh.Collector"
  1.50 1.00 2.50
  0.30 0.20 0.80)
(sdedr:define-refinement-placement
  "RefPlace.Mesh.Collector" "RefDef.Mesh.Collector" "Win.Mesh.Collector")
(sdedr:define-refinement-function "RefDef.Mesh.Collector"
  "DopingConcentration" "MaxTransDiff" 1.5)

;--------------------------------------------------------------------------
; Save, check, and build
;--------------------------------------------------------------------------

(sde:save-model "n@node@_geo")
(sde:check-model "n@node@_sde_check.log")
(sde:build-mesh "n@node@_msh")

*--------------------------------------------------------------------------
* 3D GGEE IGBT clamped-inductive double-pulse turn-on simulation
* Target: ISPSD 2024 Dynamic-CSL paper, Fig. 3 / Fig. 6 turn-on waveforms.
*
* Paper conditions:
*   VCC = 400 V, Lload = 10 uH, paper reference Rg = 9 ohm, Ic ~= 300 A, Ta = 300 K.
*   ChannelDensity = 0.14 for Fig. 3; 0.22 for Fig. 6 comparison.
*
* All physical electrodes and circuit sources start from 0 V.
* This direct-gate variant removes the external Rgate to avoid AreaFactor-induced gate RC mismatch.
* The gate is driven by an ideal PWL source with a -5 V off-state.
* The load current starts from 0 A and is built by VCC and Lload.
*--------------------------------------------------------------------------

Device GGEEIGBT {
   File {
      Grid      = "@tdr@"
      Parameter = "@parameter@"
      Plot      = "@tdrdat@"
   }

   Electrode {
      { Name="emitter"   Voltage=0.0 Resist=1e-3 }
      { Name="gate"      Voltage=0.0 Resist=1e-3 }
      { Name="collector" Voltage=0.0 Resist=1e-3 }
   }

   Physics {
      Temperature = 300
      AreaFactor  = 1e6

      Fermi
      EffectiveIntrinsicDensity(
         BandGapNarrowing(Slotboom)
      )
   }

   Physics(Material="Silicon") {
      Mobility(
         DopingDependence
         Enormal(IALMob)
         HighFieldSaturation(GradQuasiFermi)
      )

      Recombination(
         SRH(DopingDependence TempDependence)
         Auger
      )
   }

   Physics(Material="PolySilicon") {
      Mobility(DopingDependence)
      Recombination(
         SRH(DopingDependence TempDependence)
         Auger
      )
   }

   Plot {
      eDensity hDensity
      eCurrent/Vector hCurrent/Vector TotalCurrent/Vector
      Potential ElectricField/Vector SpaceCharge
      Doping DonorConcentration AcceptorConcentration
      eMobility hMobility eVelocity hVelocity
      eQuasiFermi hQuasiFermi
      eGradQuasiFermi/Vector hGradQuasiFermi/Vector
      ConductionBand ValenceBand BandGap
      SRHRecombination AugerRecombination
   }

   * Internal probes for the paper mechanism.
   * Coordinate order follows the SDE structure: X, Y, Z in um.
   * FLP probe: left floating-P center, midway between source segments.
   * DCSL probe: active mesa center in the source-free Wp section.
   * Channel probe: active mesa center directly below an N+ source.
   CurrentPlot {
      Potential(
         (2.00 1.80 10.00)
      )
      eDensity(
         (2.00 3.35 10.00)
         (2.00 3.35  5.00)
      )
   }
}

File {
   Current   = "@plot@"
   Output    = "@log@"
}

Math {
   Extrapolate
   Derivatives
   RelErrControl

   Digits=5
   ErrRef(Electron)=1e10
   ErrRef(Hole)=1e10
   RHSMin=1e-10

   Iterations=45
   NotDamped=100
   Method=ParDiSo
   Transient=BE

   RefDens_eGradQuasiFermi_ElectricField_HFS=1e12
   RefDens_hGradQuasiFermi_ElectricField_HFS=1e12
   ParallelToInterfaceInBoundaryLayer
   SimStats
}

*--------------------------------------------------------------------------
* Double-pulse circuit
*
* VBUS -- Lload -- switch -- Lstray -- DUT collector
*                   |
*                   +---- Dfw ---- VBUS
*
* First pulse: 0.505 us to 8.005 us, approximately 7.5 us on-time.
* Ideal estimate: Delta I = 400 V / 10 uH * 7.5 us = 300 A.
* Second pulse begins at 12.000 us after a 3.99 us negative-gate off interval.
*--------------------------------------------------------------------------

System {
   GGEEIGBT DUT (
      emitter   = 0
      gate      = gate
      collector = collector
   )

   Vsource_pset Vbus (vbus 0) {
      pwl = (
         0.000e-6     0
         0.200e-6   400
        12.800e-6   400
      )
   }

   * No ic parameter: inductor current starts from 0 A.
   Inductor_pset Lload (vbus switch) {
      inductance = 10e-6
   }

   * Small commutation inductance; not specified in the paper.
   Inductor_pset Lstray (switch collector) {
      inductance = 10e-9
   }

   * Use the built-in default diode parameter set directly.
   Diode_pset Dfw (switch vbus) {
      area = 1.0
   }

   * Direct gate drive: no external Rgate.
   * The -5 V off-state guarantees full channel turn-off before the second pulse.
   Vsource_pset Vgate (gate 0) {
      pwl = (
         0.000e-6     0
         0.500e-6     0
         0.505e-6    15
         8.005e-6    15
         8.010e-6    -5
        11.995e-6    -5
        12.000e-6    15
        12.800e-6    15
      )
   }

   Plot "n@node@_Paper_DPT_TurnOn" (
      time()
      v(vbus)
      v(switch)
      v(collector)
      v(gate)
      i(DUT collector)
      i(DUT gate)
      i(Dfw switch)
      i(Lload vbus)
      i(Lstray collector)
      i(Vbus vbus)
      i(Vgate gate)
   )
}

Solve {
   * Zero-bias equilibrium of device and circuit.
   Coupled(
      Iterations=120
      LineSearchDamping=1e-4
   ) {
      Poisson Circuit
   }

   Coupled(
      Iterations=100
      LineSearchDamping=1e-3
   ) {
      Poisson Electron Hole Circuit
   }

   * Bus ramp and off-state stabilization.
   NewCurrentPrefix="DPT_BusRamp_"

   Transient(
      InitialTime=0.0
      FinalTime=4.50e-7
      InitialStep=1e-12
      Increment=1.35
      Decrement=2.0
      MinStep=1e-14
      MaxStep=1e-8
   ) {
      Coupled(
         Iterations=55
         LineSearchDamping=0.20
      ) {
         Poisson Electron Hole Circuit
      }

      CurrentPlot(
         Time=(Range=(0.0 4.50e-7) Intervals=45)
      )
   }

   * Resolve the first turn-on edge.
   NewCurrentPrefix="DPT_FirstTurnOn_"

   Transient(
      InitialTime=4.50e-7
      FinalTime=6.50e-7
      InitialStep=1e-12
      Increment=1.25
      Decrement=2.0
      MinStep=1e-14
      MaxStep=1e-9
   ) {
      Coupled(
         Iterations=65
         LineSearchDamping=0.15
      ) {
         Poisson Electron Hole Circuit
      }

      CurrentPlot(
         Time=(Range=(4.50e-7 6.50e-7) Intervals=160)
      )
   }

   * Build the load current from approximately 0 A to 300 A.
   NewCurrentPrefix="DPT_CurrentBuild_"

   Transient(
      InitialTime=6.50e-7
      FinalTime=7.95e-6
      InitialStep=1e-9
      Increment=1.40
      Decrement=2.0
      MinStep=1e-14
      MaxStep=5e-8
   ) {
      Coupled(
         Iterations=55
         LineSearchDamping=0.20
      ) {
         Poisson Electron Hole Circuit
      }

      CurrentPlot(
         Time=(Range=(6.50e-7 7.95e-6) Intervals=160)
      )
   }

   * First turn-off and transfer of current to the freewheel diode.
   NewCurrentPrefix="DPT_FirstTurnOff_"

   Transient(
      InitialTime=7.95e-6
      FinalTime=8.20e-6
      InitialStep=1e-12
      Increment=1.25
      Decrement=2.0
      MinStep=1e-14
      MaxStep=1e-9
   ) {
      Coupled(
         Iterations=70
         LineSearchDamping=0.12
      ) {
         Poisson Electron Hole Circuit
      }

      CurrentPlot(
         Time=(Range=(7.95e-6 8.20e-6) Intervals=200)
      )
   }

   * Extended freewheeling interval; verify VGE=-5 V and Vswitch is near Vbus before the second pulse.
   NewCurrentPrefix="DPT_Freewheel_"

   Transient(
      InitialTime=8.20e-6
      FinalTime=11.95e-6
      InitialStep=1e-10
      Increment=1.35
      Decrement=2.0
      MinStep=1e-14
      MaxStep=2e-8
   ) {
      Coupled(
         Iterations=60
         LineSearchDamping=0.18
      ) {
         Poisson Electron Hole Circuit
      }

      CurrentPlot(
         Time=(Range=(8.20e-6 11.95e-6) Intervals=100)
      )
   }

   Save(FilePrefix="n@node@_BeforeSecondTurnOn")

   * Dense solution around the direct-driven second hard turn-on edge at 12.000 us.
   NewCurrentPrefix="DPT_SecondTurnOn_"

   Transient(
      InitialTime=11.95e-6
      FinalTime=12.15e-6
      InitialStep=1e-12
      Increment=1.20
      Decrement=2.0
      MinStep=1e-14
      MaxStep=1e-9
   ) {
      Coupled(
         Iterations=75
         LineSearchDamping=0.10
      ) {
         Poisson Electron Hole Circuit
      }

      CurrentPlot(
         Time=(Range=(11.95e-6 12.15e-6) Intervals=240)
      )

      Plot(
         FilePrefix="n@node@_TurnOnState"
         Time=(
             11.990e-6;
            12.005e-6;
            12.020e-6;
            12.040e-6;
            12.070e-6;
            12.110e-6
         )
         NoOverwrite
      )
   }

   * Resolve the voltage-tail and FLP-potential relaxation interval.
   Transient(
      InitialTime=12.15e-6
      FinalTime=12.80e-6
      InitialStep=2e-10
      Increment=1.30
      Decrement=2.0
      MinStep=1e-14
      MaxStep=5e-9
   ) {
      Coupled(
         Iterations=70
         LineSearchDamping=0.12
      ) {
         Poisson Electron Hole Circuit
      }

      CurrentPlot(
         Time=(Range=(12.15e-6 12.80e-6) Intervals=260)
      )

      Plot(
         FilePrefix="n@node@_TurnOnState"
         Time=(
            12.170e-6;
            12.250e-6;
            12.400e-6;
            12.750e-6
         )
         NoOverwrite
      )
   }

   Plot(FilePrefix="n@node@_Paper_DPT_Final")
}

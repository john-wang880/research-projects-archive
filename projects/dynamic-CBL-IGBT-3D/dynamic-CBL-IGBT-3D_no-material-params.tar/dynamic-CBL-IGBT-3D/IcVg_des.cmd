*----------------------------------------------------------------------
* 3D GGEE Dynamic-CSL IGBT Ic-Vg simulation
* Condition: VCE = 5 V, VGE = 0 -> 15 V, T = 300 K.
* All electrodes start from 0 V. AreaFactor = 1e6.
*----------------------------------------------------------------------

File {
   Grid      = "@tdr@"
   Parameter = "@parameter@"
   Plot      = "@tdrdat@"
   Current   = "@plot@"
   Output    = "@log@"
}

Electrode {
   { Name="emitter"   Voltage=0.0 }
   { Name="gate"      Voltage=0.0 }
   { Name="collector" Voltage=0.0 }
}

Physics {
   Temperature = 300
   AreaFactor  = 1e6

   Fermi
   EffectiveIntrinsicDensity(
      BandGapNarrowing(Slotboom)
   )
}

Physics(Material="Silicon") {
   Mobility(
      DopingDependence
      Enormal(IALMob)
      HighFieldSaturation(GradQuasiFermi)
   )

   Recombination(
      SRH(DopingDependence TempDependence)
      Auger
   )
}

Physics(Material="PolySilicon") {
   Mobility(DopingDependence)
   Recombination(SRH(DopingDependence TempDependence) Auger)
}

Plot {
   eDensity hDensity
   eCurrent/Vector hCurrent/Vector TotalCurrent/Vector
   Potential ElectricField/Vector SpaceCharge
   Doping DonorConcentration AcceptorConcentration
   eMobility hMobility eVelocity hVelocity
   eQuasiFermi hQuasiFermi
   eGradQuasiFermi/Vector hGradQuasiFermi/Vector
   ConductionBand ValenceBand BandGap
   SRHRecombination AugerRecombination
}

Math {
   Extrapolate
   Derivatives
   RelErrControl

   Digits=5
   ErrRef(Electron)=1e10
   ErrRef(Hole)=1e10
   RHSMin=1e-10

   Iterations=45
   NotDamped=15
   Method=ParDiSo

   RefDens_eGradQuasiFermi_ElectricField_HFS=1e12
   RefDens_hGradQuasiFermi_ElectricField_HFS=1e12
   ParallelToInterfaceInBoundaryLayer
   SimStats
}

Solve {
   * Equilibrium initialization.
   Coupled(
      Iterations=120
      LineSearchDamping=1e-4
   ) {
      Poisson
   }

   Coupled(
      Iterations=100
      LineSearchDamping=1e-3
   ) {
      Poisson Electron Hole
   }

   * Ramp collector from 0 V to 5 V while gate remains at 0 V.
   NewCurrentPrefix="IcVg_Init_"

   Quasistationary(
      InitialStep=1e-3
      Increment=1.45
      Decrement=2.0
      MinStep=1e-8
      MaxStep=0.04
      Goal { Name="collector" Voltage=5.0 }
   ) {
      Coupled(
         Iterations=50
         LineSearchDamping=0.20
      ) {
         Poisson Electron Hole
      }
   }

   Save(FilePrefix="n@node@_IcVg_Vce5V")

   * Transfer characteristic: VGE = 0 -> 15 V at VCE = 5 V.
   NewCurrentPrefix="IcVg_"

   Quasistationary(
      InitialStep=5e-4
      Increment=1.30
      Decrement=2.0
      MinStep=1e-9
      MaxStep=0.015
      Goal { Name="gate" Voltage=15.0 }
   ) {
      Coupled(
         Iterations=60
         LineSearchDamping=0.15
      ) {
         Poisson Electron Hole
      }

      CurrentPlot(
         Time=(Range=(0.0 1.0) Intervals=200)
      )
   }

   Plot(FilePrefix="n@node@_IcVg_Final")
}
